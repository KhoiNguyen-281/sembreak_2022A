<?php
/**
 * @Deprecated
 * @since 4.2.3
 */
class Themify_Builder_Updater {
	public function __construct( $name, $version, $slug ) {}
}